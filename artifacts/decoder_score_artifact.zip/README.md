# LatentSieve decoder score records

The CSV files use anonymous image and prompt-group identifiers. They contain verification scores and block counts.

## Earlier decoder experiment

- earlier_shift_scores.csv contains the two paired scores for each archived SHIFT image at strengths 0.6 and 0.7. There are 200 images per strength.
- earlier_null_scores.csv contains the scores for 2,000 calibration and 2,000 independent test images. These unmarked images were generated on SD 2.1 from distinct MS-COCO captions using 25 generation steps, followed by 50-step prompt-conditioned inversion.
- earlier_protocol.json records the benchmark configuration and the hashes of the local checkpoint and receiver configuration.
- within_image_counts.csv contains the agreeing block counts among the 32 discarded and 224 retained blocks on each of the same 500 marked SDP images in each condition.
- within_image_summary.json reports image-averaged agreement and 95% percentile bootstrap intervals for the paired differences. Each of the 20,000 draws resamples the 100 prompt groups, retaining all five images per group.

To reproduce the earlier thresholds, sort each column on the calibration split and use the 21st-highest score. Accept strictly above the threshold. Count acceptances on the independent test split and in each marked condition. For the within-image comparison, divide the two block counts by 32 and 224 before taking the per-image difference.

## Stricter operating point

- paired_scores.csv contains the paired three-decoder scores for the 500 SHIFT images, the 4,000 calibration images, and the 4,000 held-out test images.
- protocol.json records the benchmark design and code and configuration hashes.
- strict_fpr_results.json contains the primary results and the post hoc comparison that matches the erasure detector's realized false-positive count.
- analyze_strict_fpr.py and decoder_evidence.py reproduce the score-level analysis using Python and NumPy. Run from this directory:

    python analyze_strict_fpr.py . reproduced --paired-scores paired_scores.csv --protocol protocol.json --draws 20000

The paired score export supports statistical reproduction without images, model weights, or a watermark key.

## Exploratory calibration sweep

Run `python sweep_fpr.py` in this directory to regenerate `fpr_sweep.csv`. It uses seven calibration targets, 0.10%, 0.25%, 0.50%, 0.75%, 1.00%, 1.50%, and 2.00%. Each threshold uses only the calibration split. The CSV gives the cutoff, calibration and test false-positive counts, test false-positive rate, and true-positive count and rate for each decoder. The 0.50% row repeats the original primary operating point. Other rows reuse the same score panel as a post hoc sensitivity analysis.

## Within-image agreement under strong SHIFT

- shift_block_agreement_counts.csv contains the numbers of agreeing blocks among the 224 retained and 32 discarded blocks for each of the same 500 marked images in the SHIFT 0.80 panel.
- shift_block_agreement_summary.json reports the mean paired difference and its 95% percentile interval from 20,000 prompt-cluster bootstrap draws. The comparison was performed after the decoder evaluation.
- Reproduce these values from the recorded counts using Python and NumPy:

    python shift_block_agreement.py
