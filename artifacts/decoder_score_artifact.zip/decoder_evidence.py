"""Analyze paired watermark scores and pre-erasure block reliability.

Input is JSON Lines. Each row is one image under one condition and has
protocol_id, split, condition, image_id, prompt_id, and block_correlations.
The 256 correlations are signed dot products with the enrolled reference,
in block-index order. Use split=marked, null_calibration, or null_test.
For non-generated negatives, prompt_id can be the image_id.
"""

import argparse
from collections import defaultdict
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path

import numpy as np


BLOCKS = 256
RETAINED = 224
SPLITS = {"marked", "null_calibration", "null_test"}


def read_records(path):
    records = defaultdict(list)
    seen = set()
    protocols = set()
    with path.open(encoding="utf-8-sig") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                protocol, split, condition, image, prompt = (
                    row[name] for name in
                    ("protocol_id", "split", "condition", "image_id", "prompt_id")
                )
                if not all(isinstance(x, str) and x for x in
                           (protocol, split, condition, image, prompt)):
                    raise ValueError("protocol, split, condition, and IDs must be strings")
                if split not in SPLITS:
                    raise ValueError(f"unknown split {split!r}")
                key = (split, condition, image)
                if key in seen:
                    raise ValueError(f"duplicate image in condition {condition!r}")
                correlations = np.asarray(row["block_correlations"], dtype=np.float64)
                if correlations.shape != (BLOCKS,) or not np.isfinite(correlations).all():
                    raise ValueError(f"expected {BLOCKS} finite block correlations")
                seen.add(key)
                protocols.add(protocol)
                records[split].append((condition, image, prompt, correlations))
            except (KeyError, TypeError, ValueError) as error:
                raise ValueError(f"{path}:{line_number}: {error}") from error
    if len(protocols) != 1 or not {"null_calibration", "null_test"} <= records.keys():
        raise ValueError("expected one protocol and both null splits")
    calibration, test = records["null_calibration"], records["null_test"]
    for field, name in ((1, "image"), (2, "prompt group")):
        if {row[field] for row in calibration} & {row[field] for row in test}:
            raise ValueError(f"{name} overlap between null calibration and test")
    if len({row[0] for row in calibration + test}) != 1:
        raise ValueError("use one common null condition in calibration and test")
    for split in ("null_calibration", "null_test"):
        if len({row[1] for row in records[split]}) != len(records[split]):
            raise ValueError(f"each negative image must occur once in {split}")
    return protocols.pop(), records


def score(correlations):
    confidence = np.abs(correlations)
    correct = correlations > 0
    erased = BLOCKS - RETAINED
    order = np.argsort(confidence, axis=1)
    retained = np.take_along_axis(correct, order[:, erased:], axis=1)
    boundary = np.take_along_axis(confidence, order[:, erased - 1:erased + 1], axis=1)
    return np.column_stack((correct.mean(axis=1), retained.mean(axis=1))), int(
        np.count_nonzero(boundary[:, 0] == boundary[:, 1])
    )


def threshold(scores, target_fpr):
    # The detector accepts strictly above this value. Tied null scores can
    # make the attained calibration FPR smaller than the target.
    allowed = int(target_fpr * len(scores))
    index = len(scores) - 1 - allowed
    return np.partition(scores, index, axis=0)[index], allowed


def cluster_interval(numerators, denominators, prompts, repeats, rng):
    numerators = np.asarray(numerators)
    denominators = np.asarray(denominators)
    _, cluster = np.unique(prompts, return_inverse=True)
    group_count = int(cluster.max()) + 1
    if group_count < 2:
        return None
    group_num = np.bincount(cluster, weights=numerators)
    group_den = np.bincount(cluster, weights=denominators)
    draws = []
    for start in range(0, repeats, 128):
        sample = rng.integers(0, group_count, (min(128, repeats - start), group_count))
        num = group_num[sample].sum(axis=1)
        den = group_den[sample].sum(axis=1)
        draws.extend((num[den > 0] / den[den > 0]).tolist())
    if len(draws) < 0.95 * repeats:
        return None
    return np.quantile(draws, [0.025, 0.975]).tolist()


def operating_point(scores, cutoff, rows, repeats, rng):
    decisions = scores > cutoff
    prompts = [row[2] for row in rows]
    groups = len(set(prompts))
    ones = np.ones(len(rows))
    differences = decisions[:, 1].astype(int) - decisions[:, 0].astype(int)
    rates = decisions.mean(axis=0)
    if groups == len(rows):
        intervals = [wilson_interval(float(rate), len(rows)) for rate in rates]
        interval_method = "Wilson (one observation per prompt group)"
    else:
        intervals = [
            cluster_interval(decisions[:, i], ones, prompts, repeats, rng) for i in (0, 1)
        ]
        interval_method = "prompt-cluster bootstrap"
    return {
        "n": len(rows),
        "prompt_groups": groups,
        "accepted_m1_m2": decisions.sum(axis=0).tolist(),
        "rate_m1_m2": rates.tolist(),
        "rate_ci95_m1_m2": intervals,
        "rate_ci_method": interval_method,
        "m2_minus_m1": float(differences.mean()),
        "m2_minus_m1_ci95": cluster_interval(differences, ones, prompts, repeats, rng),
        "m2_only": int(np.count_nonzero(differences == 1)),
        "m1_only": int(np.count_nonzero(differences == -1)),
    }


def wilson_interval(rate, n):
    z = 1.959963984540054
    scale = 1 + z * z / n
    center = (rate + z * z / (2 * n)) / scale
    half = z / scale * math.sqrt(rate * (1 - rate) / n + z * z / (4 * n * n))
    return [max(0, center - half), min(1, center + half)]


def confidence_bins(correlations, prompts, edges, repeats, rng):
    confidence = np.abs(correlations) / 64
    correct = correlations > 0
    bins = []
    for low, high in zip(edges[:-1], edges[1:]):
        in_bin = (confidence >= low) & (confidence < high)
        count = in_bin.sum(axis=1)
        successes = (in_bin & correct).sum(axis=1)
        n = int(count.sum())
        bins.append({
            "low_inclusive": float(low),
            "high_exclusive": float(high) if np.isfinite(high) else None,
            "blocks": n,
            "correct_blocks": int(successes.sum()),
            "images": int(np.count_nonzero(count)),
            "agreement": float(successes.sum() / n) if n else None,
            "agreement_ci95": cluster_interval(successes, count, prompts, repeats, rng) if n else None,
        })
    return bins


def archived_shift(path, cutoff, repeats, rng):
    archive = json.loads(path.read_text(encoding="utf-8"))
    conditions = {}
    for strength, variants in archive["results"].items():
        def index_variant(name, denominator):
            by_image = {}
            for item in variants[name]:
                identifier = (item["idx"], item["prompt_idx"], item["seed"])
                raw = item["ba"]
                exact = round(raw * denominator) / denominator
                if identifier in by_image or not 0 <= exact <= 1 or abs(raw - exact) > 1e-6:
                    raise ValueError(f"invalid or repeated archived score: {strength}, {name}, {identifier}")
                if bool(item["is_watermarked"]) != (exact > 0.67):
                    raise ValueError(f"archived threshold check failed for {identifier}")
                by_image[identifier] = exact
            return by_image

        m1 = index_variant("uniform_no_erase", BLOCKS)
        m2 = index_variant("uniform_erase", RETAINED)
        if not m1 or m1.keys() != m2.keys():
            raise ValueError(f"unpaired scores in archived SHIFT condition {strength}")
        images = sorted(m1)
        scores = np.array([(m1[image], m2[image]) for image in images])
        rows = [(strength, image[0], image[1]) for image in images]
        shared = operating_point(scores, 0.67, rows, repeats, rng)
        prompts, groups = np.unique([image[1] for image in images], return_inverse=True)
        group_sizes = np.bincount(groups)
        if np.all(group_sizes == group_sizes[0]):
            decisions = scores > 0.67
            differences = decisions[:, 1].astype(int) - decisions[:, 0].astype(int)
            group_sums = np.bincount(groups, weights=differences).astype(int)
            offset = int(group_sums.min())
            mass = np.bincount(group_sums - offset) / len(prompts)
            bootstrap_mass = np.array([1.0])
            for _ in prompts:
                bootstrap_mass = np.convolve(bootstrap_mass, mass)
            endpoints = np.searchsorted(np.cumsum(bootstrap_mass), [0.025, 0.975])
            shared["m2_minus_m1_ci95"] = ((endpoints + offset * len(prompts)) / len(images)).tolist()
            shared["difference_ci_method"] = "exact distribution of prompt-cluster bootstrap"
        conditions[strength] = {
            "shared_threshold_0_67": shared,
            "calibrated_thresholds": operating_point(scores, cutoff, rows, repeats, rng),
        }
    return {
        "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "conditions": conditions,
    }


def analyze(path, target_fpr, repeats, seed, shift_path=None):
    protocol, records = read_records(path)
    if not records["marked"] and shift_path is None:
        raise ValueError("provide marked records or an archived SHIFT comparison")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    calibration, test = records["null_calibration"], records["null_test"]
    cal_scores, cal_ties = score(np.stack([row[3] for row in calibration]))
    test_scores, test_ties = score(np.stack([row[3] for row in test]))
    cutoff, allowed = threshold(cal_scores, target_fpr)
    rng = np.random.default_rng(seed)
    marked = defaultdict(list)
    for row in records["marked"]:
        marked[row[0]].append(row)
    conditions = {}
    if marked:
        all_confidence = np.abs(np.stack([row[3] for row in records["marked"]])) / 64
        # Common bin edges for all conditions, computed from confidence alone.
        interior = np.unique(np.quantile(all_confidence, [0.125, 0.25, 0.5, 0.75]))
        edges = np.concatenate(([0], interior[interior > 0], [np.inf]))
        for condition, rows in sorted(marked.items()):
            correlations = np.stack([row[3] for row in rows])
            scores, ties = score(correlations)
            conditions[condition] = {
                "tied_erasure_boundaries": ties,
                "tpr": operating_point(scores, cutoff, rows, repeats, rng),
                "confidence_bins": confidence_bins(
                    correlations, [row[2] for row in rows], edges, repeats, rng
                ),
            }
    result = {
        "protocol_id": protocol,
        "input_sha256": digest.hexdigest(),
        "target_fpr": float(target_fpr),
        "cutoff_m1_m2": cutoff.tolist(),
        "null_calibration": {
            "n": len(calibration),
            "allowed_accepts": allowed,
            "accepted_m1_m2": (cal_scores > cutoff).sum(axis=0).tolist(),
            "tied_erasure_boundaries": cal_ties,
        },
        "null_test": {
            "tied_erasure_boundaries": test_ties,
            "fpr": operating_point(test_scores, cutoff, test, repeats, rng),
        },
        "marked_conditions": conditions,
        "bootstrap": {
            "unit": "prompt group",
            "thresholds": "fixed at disjoint null calibration estimates",
            "repeats": repeats,
            "seed": seed,
        },
    }
    if shift_path is not None:
        result["archived_shift"] = archived_shift(shift_path, cutoff, repeats, rng)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("records", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--archived-shift", type=Path,
                        help="optional paired M1/M2 scores from gzs_shift_comparison.json")
    parser.add_argument("--target-fpr", type=Decimal, default=Decimal("0.01"))
    parser.add_argument("--bootstrap", type=int, default=4000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if not args.target_fpr.is_finite() or not 0 < args.target_fpr < 1:
        parser.error("--target-fpr must be in (0, 1)")
    if args.bootstrap < 100 or args.seed < 0:
        parser.error("use at least 100 bootstrap draws and a nonnegative seed")
    result = analyze(args.records, args.target_fpr, args.bootstrap, args.seed, args.archived_shift)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
