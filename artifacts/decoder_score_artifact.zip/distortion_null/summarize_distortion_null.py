"""Validate and summarize the fixed-cutoff unmarked distortion panels."""

import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path


GROUPS = ("sd21-sweep", "sd21-unseen", "sd21-heldout", "sd15", "flux1-dev")
EXPECTED_CONDITIONS = dict(zip(GROUPS, (21, 15, 9, 9, 4)))


def wilson_upper(count, n):
    z = 1.959963984540054
    rate = count / n
    return (rate + z*z/(2*n) + z*math.sqrt((rate*(1-rate) + z*z/(4*n))/n)) / (1 + z*z/n)


def collect(paths):
    observed = defaultdict(dict)
    expected = {}
    for path in paths:
        protocol = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        if protocol["cutoff"] != 0.67 or protocol.get("only_clean"):
            raise ValueError(f"Unexpected protocol for {path}")
        if protocol["backbone"] == "FLUX.1-dev":
            conditions = {name: ["flux1-dev"] for name in protocol["conditions"]}
        else:
            conditions = protocol["conditions"]
        for name, groups in conditions.items():
            for group in groups:
                key = (group, name)
                if group not in EXPECTED_CONDITIONS or key in expected:
                    raise ValueError(f"Duplicate or unknown group / condition pair {key}")
                expected[key] = protocol["n"]

        with path.open(newline="", encoding="utf-8") as stream:
            for row in csv.DictReader(stream):
                group = row["group"]
                key = (group, row["condition"])
                image = int(row["image_index"])
                if row["condition"] not in conditions or group not in conditions[row["condition"]]:
                    raise ValueError(f"Unexpected group / condition pair {key} in {path}")
                if not 0 <= image < expected[key] or image in observed[key]:
                    raise ValueError(f"Duplicate or out-of-range image {image} in {key}")
                score = float(row["score"])
                accepted = score > 0.67 if group == "flux1-dev" else score >= 0.67
                if not 0 <= score <= 1 or int(row["false_positive"]) != accepted:
                    raise ValueError(f"Invalid score or decision in image {image} of {key}")
                if row["generation_seed"] == row["nonce"]:
                    raise ValueError(f"Generation and test seeds coincide in image {image} of {key}")
                observed[key][image] = (score, accepted)

    results = defaultdict(list)
    groups = {group for group, _ in expected}
    for group in sorted(groups):
        keys = [key for key in expected if key[0] == group]
        if len(keys) != EXPECTED_CONDITIONS[group]:
            raise ValueError(f"Unexpected number of conditions in {group}")
        for key in keys:
            values = observed[key].values()
            if len(values) != expected[key]:
                raise ValueError(f"Incomplete group {key}: {len(values)}/{expected[key]}")
            n = len(values)
            count = sum(hit for _, hit in values)
            results[group].append({"condition": key[1], "n": n, "false_positives": count,
                                   "max_score": max(score for score, _ in values),
                                   "wilson_upper": wilson_upper(count, n)})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("scores", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    results = collect(args.scores)
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    for group, conditions in results.items():
        print(f"{group}: {len(conditions)} conditions, n={conditions[0]['n']}, "
              f"{sum(row['false_positives'] for row in conditions)} FP, "
              f"max score {max(row['max_score'] for row in conditions):.6f}")


if __name__ == "__main__":
    main()
