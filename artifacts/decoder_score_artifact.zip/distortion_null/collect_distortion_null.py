"""Measure native LatentSieve false positives on ordinary image distortions."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace

import numpy as np
from PIL import Image
import torch


def conditions(backbone):
    from evaluation.tools.image_editor import Brightness, Mask, Overlay, AdaptiveNoiseInjection
    from evaluation.tools.image_editor import CrSc, GaussianBlurring, GaussianNoise, JPEGCompression
    from qi_eval_n500_unseen_combo_sdp import ATTACKS as unseen

    standard = {
        "Clean": lambda image: image,
        "JPEG-75": JPEGCompression(quality=75).edit,
        "Blur-2": GaussianBlurring(radius=2).edit,
        "Noise-15": GaussianNoise(sigma=15).edit,
        "CropPad-0.8": CrSc(crop_ratio=0.8, resize_back=False, pad_back=True).edit,
        "Brightness-1.2": Brightness(factor=1.2).edit,
        "Mask": Mask(mask_ratio=0.2).edit,
        "Overlay": Overlay(num_strokes=10).edit,
        "AdaptiveNoise": AdaptiveNoiseInjection(intensity=0.5).edit,
    }
    if backbone == "sd15":
        return [(name, edit, ("sd15",)) for name, edit in standard.items()]

    from qi_eval_n500_strength_sweep_sdp import ATTACK_SWEEPS

    sweep = {"Clean": standard["Clean"]}
    for family, protocol in ATTACK_SWEEPS.items():
        for strength in protocol["strengths"]:
            sweep[f"{family}-{strength}"] = protocol["factory"](strength).edit
    shared = {name: (edit, ["sd21-sweep"]) for name, edit in sweep.items()}
    for name, edit in standard.items():
        shared.setdefault(name, (edit, []))[1].append("sd21-heldout")
    for name, edit in unseen.items():
        shared[name] = (edit, ["sd21-unseen"])
    return [(name, edit, profiles) for name, (edit, profiles) in shared.items()]


def load_models(args):
    from diffusers import DPMSolverMultistepScheduler, StableDiffusionPipeline
    from utils.diffusion_config import DiffusionConfig
    from watermark.mirage.mirage import MIRAGEConfig, MIRAGE, MIRAGEUtils

    dtype = {"fp32": torch.float32, "fp16": torch.float16}[args.precision]
    torch.backends.cuda.matmul.allow_tf32 = args.tf32
    torch.backends.cudnn.allow_tf32 = args.tf32
    scheduler = DPMSolverMultistepScheduler.from_pretrained(
        args.model, subfolder="scheduler", local_files_only=True,
    )
    pipe = StableDiffusionPipeline.from_pretrained(
        args.model, scheduler=scheduler, torch_dtype=dtype,
        safety_checker=None, local_files_only=True,
    ).to("cuda")
    pipe.set_progress_bar_config(disable=True)
    pipe.register_to_config(_name_or_path={
        "sd21": "huanzi05/stable-diffusion-2-1-base",
        "sd15": "sd-legacy/stable-diffusion-v1-5",
    }[args.backbone])
    dc = DiffusionConfig(
        scheduler=scheduler, pipe=pipe, device="cuda", image_size=(512, 512),
        num_inference_steps=50, num_inversion_steps=50, guidance_scale=7.5,
        gen_seed=42, inversion_type="ddim", dtype=dtype,
    )
    cache = args.archive / "watermark/mirage/cache"
    profiles = {}
    calibration = {}
    for config_name in ("presence", "heldout_calibration"):
        if config_name == "heldout_calibration" and args.backbone == "sd15":
            continue
        cfg = MIRAGEConfig(str(args.archive / f"config/MIRAGE_{config_name}.json"), dc)
        cfg.cache_dir = str(cache)
        path = MIRAGEUtils._cache_path(SimpleNamespace(config=cfg, cache_dir=cache))
        if not path.is_file():
            raise FileNotFoundError(path)
        receiver = MIRAGE(cfg)
        if (cfg.num_blocks, cfg.block_dim, cfg.presence_erasure_bits, cfg.presence_bitacc_threshold) != (256, 64, 32, 0.67):
            raise ValueError(f"Unexpected receiver parameters in {config_name}")
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        calibration[config_name] = {"filename": path.name, "sha256": checksum}
        print(f"{config_name}: cache={path.name} sha256={checksum}", flush=True)
        profiles[config_name] = receiver
    return pipe, profiles, calibration


@torch.inference_mode()
def invert_batch(receiver, images, prompts):
    from utils.media_utils import get_media_latents, transform_to_model_format

    cfg = receiver.config
    positive, negative = cfg.pipe.encode_prompt(
        prompt=prompts, device=cfg.device, do_classifier_free_guidance=True,
        num_images_per_prompt=1,
    )
    pixels = torch.stack([transform_to_model_format(image, target_size=512) for image in images])
    latents = get_media_latents(cfg.pipe, pixels.to(device=cfg.device, dtype=cfg.dtype), sample=False)
    return cfg.inversion.forward_diffusion(
        latents=latents, text_embeddings=torch.cat([negative, positive]),
        guidance_scale=cfg.guidance_scale, num_inference_steps=cfg.num_inference_steps,
    )[-1]


def unmarked_image(args, pipe, index, prompt, seed):
    if args.backbone == "sd21":
        path = args.archive / f"qi_eval_n500_sdp/UNWM_sdp/img_{index:04d}.png"
    else:
        path = args.output.parent / f"sd15_unmarked/{args.precision}_{int(args.tf32)}/img_{index:04d}.png"
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            generator = torch.Generator(device="cuda").manual_seed(seed)
            image = pipe(prompt, num_inference_steps=50, guidance_scale=7.5,
                         generator=generator, height=512, width=512).images[0]
            temp = path.with_suffix(".tmp")
            image.save(temp, format="PNG")
            temp.replace(path)
    with Image.open(path) as image:
        return image.convert("RGB")


def run(args):
    sys.path.insert(0, str(args.archive))
    from qi_sdp_n500_config import PROMPTS as sdp_prompts
    from qi_eval_n500_sd15 import PROMPTS as sd15_prompts

    prompts = sdp_prompts if args.backbone == "sd21" else sd15_prompts
    recipes = conditions(args.backbone)
    if args.only_clean:
        recipes = [recipe for recipe in recipes if recipe[0] == "Clean"]
    pipe, profiles, calibration = load_models(args)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    meta = {"backbone": args.backbone, "precision": args.precision, "tf32": args.tf32,
            "calibration": calibration, "generation_steps": 50, "inversion_steps": 50, "guidance": 7.5,
            "n": args.n, "only_clean": args.only_clean, "conditions": {
                name: list(groups) for name, _, groups in recipes}, "cutoff": 0.67}
    protocol = args.output.with_suffix(".json")
    if protocol.exists():
        earlier_fields = json.loads(protocol.read_text())
        if any(meta.get(key) != value for key, value in earlier_fields.items()):
            raise ValueError(f"Existing output uses another protocol: {protocol}")
    protocol.write_text(json.dumps(meta, indent=2) + "\n")
    fields = ["image_index", "prompt_index", "generation_seed", "edit_seed", "nonce",
              "group", "condition", "score", "false_positive"]
    seen = set()
    if args.output.is_file():
        with args.output.open(newline="") as file:
            seen = {(int(row["image_index"]), row["group"], row["condition"]) for row in csv.DictReader(file)}
    start = time.monotonic()
    processed = 0
    with args.output.open("a", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        if not seen and file.tell() == 0:
            writer.writeheader()
        for first in range(0, args.n, args.batch):
            indices = list(range(first, min(first + args.batch, args.n)))
            todo = [(name, edit, groups) for name, edit, groups in recipes if any(
                (index, group, name) not in seen for index in indices for group in groups
            )]
            if not todo:
                continue
            texts = [prompts[index % len(prompts)] for index in indices]
            seeds = [(7_000_000 if args.backbone == "sd21" else 57_000_000) + index for index in indices]
            images = [unmarked_image(args, pipe, i, p, s) for i, p, s in zip(indices, texts, seeds)]
            for name, edit, groups in todo:
                draws = [int.from_bytes(hashlib.sha256(f"{args.backbone}/{index}/{name}/edit".encode()).digest()[:4], "big")
                         for index in indices]
                edited = []
                for image, draw in zip(images, draws):
                    random.seed(draw)
                    np.random.seed(draw)
                    edited.append(edit(image.copy()))
                inverted = invert_batch(profiles["presence"], edited, texts)
                for i, index in enumerate(indices):
                    nonce = seeds[i] if args.only_clean else 71_000_000 + index
                    for group in groups:
                        if (index, group, name) in seen:
                            continue
                        profile = profiles["heldout_calibration" if group == "sd21-heldout" else "presence"]
                        profile.detector.update_sign_pattern(profile.utils._generate_sign_pattern(nonce))
                        score = profile.detector.eval_watermark(inverted[i])
                        writer.writerow(dict(image_index=index, prompt_index=index % len(prompts),
                                             generation_seed=seeds[i], edit_seed=draws[i], nonce=nonce,
                                             group=group, condition=name, score=score["presence_score"],
                                             false_positive=int(score["is_watermarked"])))
                file.flush()
                processed += len(indices)
            elapsed = time.monotonic() - start
            print(f"{args.backbone} images {indices[-1]+1}/{args.n}, {processed} inversions, "
                  f"{elapsed / max(processed, 1):.2f} s/inversion", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backbone", choices=("sd21", "sd15"), required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--precision", choices=("fp32", "fp16"), default="fp32")
    parser.add_argument("--tf32", action="store_true")
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--only-clean", action="store_true")
    args = parser.parse_args()
    if args.n < 1 or args.batch < 1 or (args.backbone == "sd21" and args.n > 200):
        parser.error("invalid sample count or batch size")
    run(args)


if __name__ == "__main__":
    main()
