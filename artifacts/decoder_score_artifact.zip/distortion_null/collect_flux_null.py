"""Measure the archived FLUX.1-dev detector on independently seeded unmarked images."""

import argparse
import csv
from functools import wraps
import gc
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image
import torch


DEVICE = torch.device("cuda:0")
DTYPE = torch.bfloat16
SIZE = 512
STEPS = 28
GUIDANCE = 3.5
CONDITIONS = {"Clean": "clean", "JPEG-75": "jpeg75", "Blur-2": "blur2", "Noise-15": "noise15"}


def make_embeddings(args, prompts):
    from diffusers import FluxPipeline

    args.embeddings.mkdir(parents=True, exist_ok=True)
    indices = [index for index in range(min(args.n, len(prompts)))
               if not (args.embeddings / f"{index:04d}.pt").exists()]
    if not indices:
        return
    pipe = FluxPipeline.from_pretrained(
        args.model, transformer=None, vae=None, torch_dtype=DTYPE, local_files_only=True,
    ).to(DEVICE)
    for index in indices:
        destination = args.embeddings / f"{index:04d}.pt"
        prompt = prompts[index]
        embeds = pipe.encode_prompt(prompt=prompt, prompt_2=prompt, max_sequence_length=512, device=DEVICE)
        partial = destination.with_suffix(".tmp")
        torch.save(tuple(value.cpu() for value in embeds), partial)
        partial.replace(destination)
    del pipe
    gc.collect()
    torch.cuda.empty_cache()
    print(f"Prepared {len(indices)} FLUX prompt embeddings", flush=True)


def load_receiver(args):
    from accelerate import (
        infer_auto_device_map, init_empty_weights, load_checkpoint_and_dispatch,
        load_checkpoint_in_model,
    )
    from accelerate.hooks import AlignDevicesHook, add_hook_to_module
    from diffusers import FluxPipeline, FluxTransformer2DModel

    # Keep original BF16 weights. CPU and disk dispatch accommodate a 16 GiB GPU.
    args.offload.mkdir(parents=True, exist_ok=True)
    checkpoint = args.model / "transformer"
    config = FluxTransformer2DModel.load_config(checkpoint, local_files_only=True)
    with init_empty_weights():
        transformer = FluxTransformer2DModel.from_config(config)
    block_classes = transformer._no_split_modules
    memory = {0: args.gpu_memory, "cpu": args.cpu_memory}
    # Load BF16 directly. Diffusers 0.31's from_pretrained calls .to(dtype)
    # after dispatch, which fails for already offloaded tensors.
    if args.inversion_batch > 1:
        preload = [*block_classes, type(transformer.norm_out).__name__]
        placement = infer_auto_device_map(
            transformer, max_memory=memory, dtype=DTYPE,
            no_split_module_classes=preload, clean_result=False,
        )
        for name in ("transformer_blocks", "single_transformer_blocks"):
            # ModuleList itself has no forward. Attach hooks to its blocks.
            if name in placement:
                device = placement.pop(name)
                placement.update({f"{name}.{i}": device for i, _ in enumerate(transformer.get_submodule(name))})
        if "disk" in placement.values():
            raise RuntimeError("Blockwise FLUX inference needs enough GPU and CPU memory to hold all weights")
        load_checkpoint_in_model(
            transformer, str(checkpoint), dtype=DTYPE, device_map=placement,
            offload_state_dict=True, strict=True,
        )
        for name, device in placement.items():
            if device == "cpu":
                # One hook covers the full block, so its single-image forwards share the weights.
                hook = AlignDevicesHook(execution_device=DEVICE, offload=True, place_submodules=True)
                add_hook_to_module(transformer.get_submodule(name), hook)
        transformer.hf_device_map = placement
        install_single_image_forwards(transformer)
    else:
        transformer = load_checkpoint_and_dispatch(
            transformer, checkpoint=str(checkpoint), dtype=DTYPE,
            device_map="auto", max_memory=memory, no_split_module_classes=block_classes,
            offload_folder=str(args.offload), offload_state_dict=True, strict=True,
        )
    transformer.eval()
    pipe = FluxPipeline.from_pretrained(
        args.model, transformer=None, text_encoder=None, text_encoder_2=None,
        torch_dtype=DTYPE, local_files_only=True,
    )
    pipe.vae.to(DEVICE)
    pipe.register_modules(transformer=transformer)
    pipe.set_progress_bar_config(disable=True)
    print("Transformer placement:", transformer.hf_device_map, flush=True)
    return pipe


class PromptCache:
    """Supply the same text embeddings in generation and all four inversions."""

    def __init__(self, pipe, encodings):
        self.pipe = pipe
        self.encodings = encodings

    def __getattr__(self, name):
        return getattr(self.pipe, name)

    def encode_prompt(self, *args, **kwargs):
        return self.encodings

    @staticmethod
    def _prepare_latent_image_ids(_batch_size, height, width, device, dtype):
        # The archived inverter passes the packed grid dimensions.
        # Diffusers versions disagree on whether the helper halves them.
        rows, columns = torch.meshgrid(
            torch.arange(height, device=device),
            torch.arange(width, device=device),
            indexing="ij",
        )
        ids = torch.stack((torch.zeros_like(rows), rows, columns), dim=-1)
        return ids.reshape(height * width, 3).to(dtype=dtype)


def output_fields():
    return ["image_index", "prompt_index", "generation_seed", "edit_seed", "nonce",
            "group", "condition", "score", "false_positive"]


def edit_condition(image, index, name, apply_distortion):
    edit_seed = int.from_bytes(hashlib.sha256(f"flux/{index}/{name}".encode()).digest()[:4], "big")
    np.random.seed(edit_seed)
    return apply_distortion(image, CONDITIONS[name]), edit_seed


def invert_batch(pipe, cases, encodings):
    from diffusers.pipelines.flux.pipeline_flux import calculate_shift
    from torchvision import transforms
    from qi_flux_mirage_sdp_n500 import pack_latents, unpack_latents

    latents = []
    for image, seed in cases:
        # Keep VAE sampling single-image and restore the original seed for each distortion.
        torch.manual_seed(seed)
        pixels = (transforms.ToTensor()(image.convert("RGB")) * 2 - 1)
        pixels = pixels.unsqueeze(0).to(DEVICE, dtype=DTYPE)
        pixels = transforms.functional.resize(pixels, [SIZE, SIZE], antialias=True)
        latent = pipe.vae.encode(pixels).latent_dist.sample()
        latents.append((latent - pipe.vae.config.shift_factor) * pipe.vae.config.scaling_factor)
    height, width = latents[0].shape[-2:]
    z = pack_latents(torch.cat(latents))
    image_ids = PromptCache._prepare_latent_image_ids(len(cases), height // 2, width // 2, DEVICE, DTYPE)
    scheduler = pipe.scheduler
    if getattr(scheduler.config, "use_dynamic_shifting", False):
        mu = calculate_shift(
            z.shape[1], scheduler.config.get("base_image_seq_len", 256),
            scheduler.config.get("max_image_seq_len", 4096), scheduler.config.get("base_shift", 0.5),
            scheduler.config.get("max_shift", 1.15),
        )
        scheduler.set_timesteps(STEPS, device=DEVICE, mu=mu)
    else:
        scheduler.set_timesteps(STEPS, device=DEVICE)
    rev_sigmas = list(reversed(scheduler.sigmas.tolist()))
    rev_timesteps = list(reversed(scheduler.timesteps.tolist()))
    prompt, pooled, text_ids = encodings
    prompt = prompt.expand(len(cases), -1, -1)
    pooled = pooled.expand(len(cases), -1)
    guidance = torch.full((len(cases),), GUIDANCE, device=DEVICE, dtype=DTYPE)
    # Move each offloaded transformer weight once per step for all the distortions.
    for i, value in enumerate(rev_timesteps[:-1]):
        timestep = torch.full((len(cases),), value / 1000.0, device=DEVICE, dtype=DTYPE)
        noise = pipe.transformer(
            hidden_states=z, timestep=timestep, guidance=guidance, pooled_projections=pooled,
            encoder_hidden_states=prompt, txt_ids=text_ids, img_ids=image_ids,
            joint_attention_kwargs=None, return_dict=False,
        )[0]
        z = z + (rev_sigmas[i + 1] - rev_sigmas[i]) * noise
    return unpack_latents(z, height, width).cpu()


def read_encodings(args, prompt_index):
    cached = torch.load(args.embeddings / f"{prompt_index:04d}.pt", weights_only=True)
    return tuple(value.to(DEVICE) for value in cached)


def install_single_image_forwards(transformer):
    """Keep serial kernels while each offloaded block serves multiple inputs."""
    def split_forward(forward):
        @wraps(forward)
        def run(*args, **kwargs):
            batch = (args[0] if args else kwargs["hidden_states"]).shape[0]
            if batch == 1:
                return forward(*args, **kwargs)
            values = []
            for i in range(batch):
                one = lambda tensor: tensor[i:i + 1] if isinstance(tensor, torch.Tensor) else tensor
                single_args = tuple(one(x) for x in args)
                single_kwargs = {k: v if k == "image_rotary_emb" else one(v) for k, v in kwargs.items()}
                values.append(forward(*single_args, **single_kwargs))
            if isinstance(values[0], tuple):
                return tuple(torch.cat(outputs) for outputs in zip(*values))
            return torch.cat(values)

        return run

    modules = (
        transformer.x_embedder, transformer.context_embedder, transformer.time_text_embed,
        *transformer.transformer_blocks, *transformer.single_transformer_blocks,
        transformer.norm_out, transformer.proj_out,
    )
    for module in modules:
        # Accelerate runs the offload hook around _old_forward. Splitting
        # inside that call keeps one transfer per block, not per image.
        if hasattr(module, "_old_forward"):
            module._old_forward = split_forward(module._old_forward)
        else:
            module.forward = split_forward(module.forward)


def verify_batch(args, pipe, rows, images, apply_distortion, detect, signs):
    index = next((i for i in range(args.n) if all((i, condition) in rows for condition in CONDITIONS)), None)
    if index is None:
        raise ValueError("Batch validation requires one complete archived FLUX image")
    with Image.open(images / f"img_{index:04d}.png") as stored:
        image = stored.convert("RGB")
    prompt_index = int(rows[(index, "Clean")]["prompt_index"])
    encodings = read_encodings(args, prompt_index)
    start = time.monotonic()
    inverted = invert_batch(pipe, [edit_condition(image, index, c, apply_distortion) for c in CONDITIONS],
                            encodings)
    nonce = int(rows[(index, "Clean")]["nonce"])
    sign_pattern = signs(16 * (SIZE // 8) ** 2, nonce)
    comparisons = {}
    for name, z in zip(CONDITIONS, inverted):
        original = rows[(index, name)]
        rerun = detect(z, sign_pattern)
        comparisons[name] = {"serial": float(original["score"]), "batched": rerun,
                             "decision_matches": int(rerun > 0.67) == int(original["false_positive"])}
    report = {"image_index": index, "batch_size": len(CONDITIONS), "gpu_memory_budget": args.gpu_memory,
              "single_image_block_forward": True,
              "inversion_seconds": time.monotonic() - start, "comparisons": comparisons}
    args.verify_batch.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("Batch validation:", json.dumps(report), flush=True)
    if any(not x["decision_matches"] or x["serial"] != x["batched"] for x in comparisons.values()):
        raise RuntimeError("Batched inversion did not reproduce all four archived scores")


@torch.inference_mode()
def run(args):
    sys.path.insert(0, str(args.archive))
    from qi_sdp_n500_config import PROMPTS
    from qi_flux_mirage_sdp_n500 import (
        apply_attack as apply_distortion, detect_per_block_sign, flux_invert_image, make_sign_pattern,
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    manifest = args.model / "modelscope_manifest.json"
    metadata = {"backbone": "FLUX.1-dev", "n": args.n, "conditions": list(CONDITIONS),
                "precision": "bf16", "guidance": GUIDANCE, "steps": STEPS, "cutoff": 0.67,
                "weights_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest()}
    protocol = args.output.with_suffix(".json")
    if protocol.exists() and json.loads(protocol.read_text()) != metadata:
        raise ValueError(f"Existing output uses another protocol: {protocol}")
    protocol.write_text(json.dumps(metadata, indent=2) + "\n")
    rows = {}
    if args.output.is_file():
        with args.output.open(newline="") as file:
            rows = {(int(row["image_index"]), row["condition"]): row for row in csv.DictReader(file)}
    make_embeddings(args, PROMPTS)
    pipe = load_receiver(args)
    images = args.output.parent / "flux_unmarked"
    images.mkdir(exist_ok=True)
    if args.verify_batch:
        verify_batch(args, pipe, rows, images, apply_distortion, detect_per_block_sign, make_sign_pattern)
    start = time.monotonic()
    processed = 0
    with args.output.open("a", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=output_fields())
        if file.tell() == 0:
            writer.writeheader()
        for index in range(args.n):
            missing = [name for name in CONDITIONS if (index, name) not in rows]
            if not missing:
                continue
            prompt_index = index % len(PROMPTS)
            prompt = PROMPTS[prompt_index]
            encodings = read_encodings(args, prompt_index)
            generation_seed = 87_000_000 + index
            nonce = 91_000_000 + index
            image_path = images / f"img_{index:04d}.png"
            if not image_path.is_file():
                generator = torch.Generator(device=DEVICE).manual_seed(generation_seed)
                image = pipe(prompt_embeds=encodings[0], pooled_prompt_embeds=encodings[1],
                             generator=generator, height=SIZE, width=SIZE, guidance_scale=GUIDANCE,
                             num_inference_steps=STEPS).images[0]
                temp = image_path.with_suffix(".tmp")
                image.save(temp, format="PNG")
                temp.replace(image_path)
            with Image.open(image_path) as stored:
                image = stored.convert("RGB")
            sign_pattern = make_sign_pattern(16 * (SIZE // 8) ** 2, nonce)
            for offset in range(0, len(missing), args.inversion_batch):
                names = missing[offset:offset + args.inversion_batch]
                cases = [edit_condition(image, index, name, apply_distortion) for name in names]
                if len(cases) == 1:
                    edited, edit_seed = cases[0]
                    torch.manual_seed(edit_seed)
                    inverted = flux_invert_image(PromptCache(pipe, encodings), edited, prompt,
                                                 STEPS, SIZE, DEVICE, DTYPE, guidance=GUIDANCE)
                else:
                    inverted = invert_batch(pipe, cases, encodings)
                for name, (_, edit_seed), z in zip(names, cases, inverted):
                    score = detect_per_block_sign(z, sign_pattern)
                    writer.writerow(dict(image_index=index, prompt_index=prompt_index,
                                         generation_seed=generation_seed, edit_seed=edit_seed,
                                         nonce=nonce, group="flux1-dev", condition=name,
                                         score=score, false_positive=int(score > 0.67)))
                    file.flush()
            processed += 1
            print(f"FLUX.1-dev images {index+1}/{args.n}, "
                  f"{(time.monotonic() - start) / processed:.2f} s/image with four conditions", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("archive", "model", "output", "offload", "embeddings"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--gpu-memory", default="11GiB")
    parser.add_argument("--cpu-memory", default="17GiB")
    parser.add_argument("--inversion-batch", type=int, choices=(1, 4), default=1)
    parser.add_argument("--verify-batch", type=Path)
    args = parser.parse_args()
    if args.n < 1:
        parser.error("n must be positive")
    if args.verify_batch and args.inversion_batch != len(CONDITIONS):
        parser.error("batch verification requires batching all four conditions")
    if args.inversion_batch > 1 and not args.verify_batch:
        parser.error("provide --verify-batch to check score equivalence before using batched inversion")
    run(args)


if __name__ == "__main__":
    main()
