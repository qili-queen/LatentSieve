"""Replay the exploratory calibration sweep from the saved decoder scores."""

import csv
from decimal import Decimal
from pathlib import Path
import sys

import numpy as np

from analyze_strict_fpr import DECODERS, read_scores


TARGETS = ("0.10", "0.25", "0.50", "0.75", "1.00", "1.50", "2.00")


def main(output):
    _, panel = read_scores(Path("paired_scores.csv"), Path("protocol.json"))
    cal, test, marked = (
        np.stack([row[3] for row in panel[split]])
        for split in ("null_calibration", "null_test", "marked")
    )
    sorted_cal = np.sort(cal, axis=0)
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(
            ["target"]
            + [f"{short}_{metric}" for short in ("uniform", "erase", "soft")
               for metric in ("threshold", "cal_fp", "test_fp", "test_fpr", "tp", "tpr")]
        )
        for target in TARGETS:
            allowed = int(len(cal) * Decimal(target) / 100)
            cutoffs = sorted_cal[-1 - allowed]
            row = [target]
            for j in range(len(DECODERS)):
                cutoff = cutoffs[j]
                calibration_fp = int(np.count_nonzero(cal[:, j] > cutoff))
                test_fp = int(np.count_nonzero(test[:, j] > cutoff))
                tp = int(np.count_nonzero(marked[:, j] > cutoff))
                row.extend((repr(float(cutoff)), calibration_fp, test_fp,
                            f"{100 * test_fp / len(test):.3f}", tp, f"{100 * tp / len(marked):.1f}"))
            writer.writerow(row)


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else "fpr_sweep.csv"))
