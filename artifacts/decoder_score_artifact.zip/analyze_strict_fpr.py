"""Analyze the locked low-FPR test and export its paired score-level artifact."""

import argparse
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

import numpy as np

from decoder_evidence import wilson_interval


DECODERS = ("all_block_uniform", "erase_32", "all_block_confidence_weighted")
SPLITS = {"marked": 5, "null_calibration": 40, "null_test": 40}


def score(signed):
    confident = np.abs(signed)
    correct = signed > 0
    order = np.argsort(confident, axis=1, kind="stable")
    kept = np.take_along_axis(correct, order[:, 32:], axis=1)
    total = confident.sum(axis=1)
    soft = np.divide((confident * correct).sum(axis=1), total,
                     out=np.full(len(signed), .5), where=total > 0)
    return np.column_stack((correct.mean(axis=1), kept.mean(axis=1), soft))


def read_run(run):
    metadata = json.loads((run / "protocol.json").read_text(encoding="utf-8"))
    expected = metadata["design"]
    expected_id = hashlib.sha256(json.dumps(metadata, sort_keys=True).encode()).hexdigest()[:16]
    if expected["primary_marked_condition"] != "SHIFT 0.80" or expected["target_fpr"] != .005:
        raise ValueError("unexpected primary condition or FPR")
    grouped = {k: [] for k in SPLITS}
    seen = set()
    with (run / "records.jsonl").open(encoding="utf-8-sig") as stream:
        for line in stream:
            r = json.loads(line)
            if r["protocol_id"] != expected_id or r["image_id"] in seen:
                raise ValueError("duplicate row or protocol mismatch")
            signed = np.asarray(r["block_correlations"], dtype=np.float64)
            if signed.shape != (256,) or not np.isfinite(signed).all():
                raise ValueError(f"invalid correlations in {r['image_id']}")
            if r["condition"] != ("shift_0.80" if r["split"] == "marked" else "clean"):
                raise ValueError("condition does not match split")
            grouped[r["split"]].append((r["image_id"], r["prompt_id"], r["seed"], signed))
            seen.add(r["image_id"])
    validate_panel(grouped)
    return metadata, grouped


def validate_panel(grouped):
    expected_prompts = {f"sdp-{j}" for j in range(100)}
    if len({row[0] for rows in grouped.values() for row in rows}) != sum(map(len, grouped.values())):
        raise ValueError("duplicate score record")
    for split, per_prompt in SPLITS.items():
        rows = sorted(grouped[split], key=lambda row: (int(row[1].split("-")[-1]), row[0]))
        counts = Counter(r[1] for r in rows)
        if counts != dict.fromkeys(expected_prompts, per_prompt):
            raise ValueError(f"incomplete or unexpected panel in {split}: {len(rows)} rows")
        grouped[split] = rows
    seeds = [{r[2] for r in rows} for rows in grouped.values()]
    if any(len(unique) != len(rows) for unique, rows in zip(seeds, grouped.values())):
        raise ValueError("duplicated generation seed")
    if sum(map(len, seeds)) != len(set().union(*seeds)):
        raise ValueError("generation seeds overlap across splits")


def read_scores(source, protocol):
    grouped = {k: [] for k in SPLITS}
    with source.open(encoding="utf-8", newline="") as stream:
        for r in csv.DictReader(stream):
            values = np.array([float(r[label]) for label in DECODERS])
            if not np.isfinite(values).all() or not np.all((0 <= values) & (values <= 1)):
                raise ValueError(f"invalid decoder score in {r['image_id']}")
            grouped[r["split"]].append((r["image_id"], r["prompt_id"], int(r["seed"]), values))
    validate_panel(grouped)
    return json.loads(protocol.read_text(encoding="utf-8")), grouped


def bootstrap(calibration, test, marked, order_index, rng, draws):
    # Calibration and test each have 40 independently generated images per fixed
    # prompt. Resample within each stratum and preserve pairing across decoders.
    cal = calibration.reshape(100, 40, len(DECODERS))
    t = test.reshape(100, 40, len(DECODERS))
    null_difference, marks = [], []
    for start in range(0, draws, 64):
        n = min(64, draws - start)
        groups = np.arange(100)[None, :, None]
        selection = rng.integers(40, size=(n, 100, 40))
        boot_cal = cal[groups, selection].reshape(n, -1, len(DECODERS))
        cut = np.partition(boot_cal, order_index, axis=1)[:, order_index, :]
        sel_test = rng.integers(40, size=(n, 100, 40))
        boot_test = t[groups, sel_test].reshape(n, -1, len(DECODERS))
        null_difference.extend((boot_test > cut[:, None, :]).mean(axis=1))
        accepted = (marked[None, :, :] > cut[:, None, :]).reshape(n, 100, 5, len(DECODERS))
        sampled = rng.integers(100, size=(n, 100))
        marks.extend(accepted[np.arange(n)[:, None], sampled].mean(axis=(1, 2)))
    return np.asarray(null_difference), np.asarray(marks)


def bounds(x):
    return np.quantile(x, [.025, .975]).tolist()


def analyze(run, output, draws, score_source=None, protocol=None):
    if score_source is None:
        meta, records = read_run(run)
        arrays = {split: score(np.stack([r[3] for r in rows])) for split, rows in records.items()}
        input_path = run / "records.jsonl"
    else:
        meta, records = read_scores(score_source, protocol)
        arrays = {split: np.stack([r[3] for r in rows]) for split, rows in records.items()}
        input_path = score_source
    cal, test, marked = (arrays[key] for key in ("null_calibration", "null_test", "marked"))
    n_cal = len(cal)
    alpha = Decimal(str(meta["design"]["target_fpr"]))
    order_index = n_cal - 1 - int(alpha * n_cal)
    cut = np.sort(cal, axis=0)[order_index]
    test_flags, marked_flags = test > cut, marked > cut
    bootstrap_test, bootstrap_marked = bootstrap(cal, test, marked, order_index, np.random.default_rng(20261113), draws)
    result = {
        "protocol": meta,
        "bootstrap_draws": draws,
        "target_fpr": float(alpha),
        "calibration_n": n_cal,
        "test_n": len(test),
        "marked_n": len(marked),
        "source_file_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
        "decoders": {},
        "erase_minus": {},
    }
    for j, label in enumerate(DECODERS):
        false_positives = int(test_flags[:, j].sum())
        detected = int(marked_flags[:, j].sum())
        result["decoders"][label] = {
            "threshold": float(cut[j]),
            "calibration_accepted": int((cal[:, j] > cut[j]).sum()),
            "test_false_positives": false_positives,
            "test_fpr": false_positives / len(test),
            "test_fpr_wilson95": wilson_interval(false_positives / len(test), len(test)),
            "test_fpr_bootstrap95": bounds(bootstrap_test[:, j]),
            "marked_detected": detected,
            "marked_tpr": detected / len(marked),
            "marked_tpr_bootstrap95": bounds(bootstrap_marked[:, j]),
        }
    for j in (0, 2):
        delta = marked_flags[:, 1].astype(int) - marked_flags[:, j].astype(int)
        result["erase_minus"][DECODERS[j]] = {
            "tpr_difference": float(delta.mean()),
            "tpr_difference_bootstrap95": bounds(bootstrap_marked[:, 1] - bootstrap_marked[:, j]),
            "only_erasure": int((delta > 0).sum()),
            "only_comparator": int((delta < 0).sum()),
        }
    # Diagnostic only. The cutoff is selected on the held-out FPR set to
    # check how sensitive the comparison is to different realized rates.
    erasure_fp = result["decoders"]["erase_32"]["test_false_positives"]
    weighted_cutoff = np.sort(test[:, 2])[len(test) - 1 - erasure_fp]
    result["posthoc_weighting_at_erasure_test_fpr"] = {
        "threshold": float(weighted_cutoff),
        "test_false_positives": int(np.count_nonzero(test[:, 2] > weighted_cutoff)),
        "marked_detected": int(np.count_nonzero(marked[:, 2] > weighted_cutoff)),
    }

    output.mkdir(parents=True, exist_ok=True)
    with (output / "paired_scores.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("split", "image_id", "prompt_id", "seed", *DECODERS))
        for split, rows in records.items():
            for row, values in zip(rows, arrays[split]):
                writer.writerow((split, *row[:3], *values.tolist()))
    (output / "strict_fpr_results.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    (output / "protocol.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--draws", type=int, default=20_000)
    parser.add_argument("--paired-scores", type=Path)
    parser.add_argument("--protocol", type=Path)
    args = parser.parse_args()
    if args.draws < 100:
        parser.error("use at least 100 bootstrap draws")
    if (args.paired_scores is None) != (args.protocol is None):
        parser.error("--paired-scores and --protocol must be supplied together")
    analyze(args.run, args.output, args.draws, args.paired_scores, args.protocol)


if __name__ == "__main__":
    main()
