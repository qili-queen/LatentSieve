"""Reproduce the post hoc within-image block comparison at SHIFT 0.80."""

import argparse
from collections import Counter
import csv
import json
from pathlib import Path

import numpy as np

from analyze_strict_fpr import read_run
from decoder_evidence import cluster_interval


FIELDS = ("image_id", "prompt_id", "discarded_correct_of_32", "retained_correct_of_224")
DRAWS = 20_000
SEED = 20261114


def export_counts(run, output):
    _, panel = read_run(run)
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(FIELDS)
        for image_id, prompt_id, _, signed in panel["marked"]:
            ordered = np.argsort(np.abs(signed), kind="stable")
            agrees = signed[ordered] > 0
            writer.writerow((image_id, prompt_id, agrees[:32].sum(), agrees[32:].sum()))


def summarize(path):
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    prompts = [row["prompt_id"] for row in rows]
    if len(rows) != 500 or len({row["image_id"] for row in rows}) != 500:
        raise ValueError("expected 500 distinct images")
    if Counter(prompts) != {f"sdp-{i}": 5 for i in range(100)}:
        raise ValueError("expected five marked images for each of the 100 SDP prompts")
    discarded = np.array([int(row[FIELDS[2]]) for row in rows])
    retained = np.array([int(row[FIELDS[3]]) for row in rows])
    if np.any((discarded < 0) | (discarded > 32)) or np.any((retained < 0) | (retained > 224)):
        raise ValueError("block agreement count out of range")
    differences = retained / 224 - discarded / 32
    interval = cluster_interval(differences, np.ones(len(rows)), prompts, DRAWS,
                                np.random.default_rng(SEED))
    return {
        "condition": "SHIFT 0.80",
        "analysis": "post hoc",
        "n": len(rows),
        "prompt_groups": len(set(prompts)),
        "retained_agreement": float(retained.mean() / 224),
        "discarded_agreement": float(discarded.mean() / 32),
        "paired_mean_difference": float(differences.mean()),
        "difference_ci95": interval,
        "bootstrap_draws": DRAWS,
        "bootstrap_seed": SEED,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--counts", type=Path, default=Path("shift_block_agreement_counts.csv"))
    parser.add_argument("--records-run", type=Path, help="optional directory containing raw run records")
    args = parser.parse_args()
    if args.records_run is not None:
        export_counts(args.records_run, args.counts)
    print(json.dumps(summarize(args.counts), indent=2, allow_nan=False))
